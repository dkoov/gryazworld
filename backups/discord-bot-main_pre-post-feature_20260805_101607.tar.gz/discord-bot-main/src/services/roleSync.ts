import { ExtendedClient } from "../structures/Client";

const BACKEND_URL = process.env.BACKEND_INTERNAL_URL ?? "http://backend:8000";
const API_KEY = process.env.INTERNAL_API_KEY ?? "";
const GUILD_ID = process.env.GUILD_ID ?? "";
const SYNC_INTERVAL_MS = 20 * 1000;
const MEMBER_CALL_TIMEOUT_MS = 10 * 1000;

/** Minecraft-роль (cs_roles.name) -> Discord-роль. Owner намеренно не синкается. */
const MC_TO_DISCORD_ROLE: Record<string, string> = {
  Banker: "1523054711392043008", // Банкир
  Helper: "1518943489142952068", // Хелпер
  IchoPlus: "1470758280510050327", // IchoPlus
  Keeper: "1523055065336909955", // Строитель
  "Куратор": "1470756818354438281", // Куратор
  Moderator: "1470756763522437171", // Модератор
  Police: "1523054974450401441", // СБИ
  "Судья": "1522969933850611752", // Судья
  AccessPass: "1470758280510050327", // Проходка (access_seasonal)
};

const MANAGED_ROLE_IDS = new Set(Object.values(MC_TO_DISCORD_ROLE));

interface RoleSyncEntry {
  discord_id: string;
  roles: string[];
}

async function fetchRoleSyncData(): Promise<RoleSyncEntry[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10_000);
  try {
    const res = await fetch(`${BACKEND_URL}/internal/discord/role-sync`, {
      headers: { "x-api-key": API_KEY },
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`backend ${res.status}`);
    return (await res.json()) as RoleSyncEntry[];
  } finally {
    clearTimeout(timer);
  }
}

// discord.js не даёт отменить REST-запрос на середине, поэтому просто гоним промис
// наперегонки с таймером — если Discord API подвиснет на одном участнике (сеть,
// рейт-лимит), это как раньше НЕ обрушит весь проход навечно (см. syncInProgress ниже).
function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout: ${label}`)), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); }
    );
  });
}

export async function syncRoles(client: ExtendedClient): Promise<void> {
  if (!API_KEY || !GUILD_ID) return;

  let entries: RoleSyncEntry[];
  try {
    entries = await fetchRoleSyncData();
  } catch (e) {
    console.error("[RoleSync] не удалось получить данные с бэкенда:", e);
    return;
  }

  const guild = client.guilds.cache.get(GUILD_ID) ?? (await client.guilds.fetch(GUILD_ID).catch(() => null));
  if (!guild) {
    console.warn(`[RoleSync] гильдия ${GUILD_ID} не найдена`);
    return;
  }

  for (const entry of entries) {
    const shouldHave = new Set(
      entry.roles.map((r) => MC_TO_DISCORD_ROLE[r]).filter((id): id is string => Boolean(id))
    );

    let member;
    try {
      member =
        guild.members.cache.get(entry.discord_id) ??
        (await withTimeout(
          guild.members.fetch(entry.discord_id),
          MEMBER_CALL_TIMEOUT_MS,
          `members.fetch(${entry.discord_id})`
        ));
    } catch {
      continue; // игрок покинул сервер, ещё не заходил, или Discord API подвис -- пропускаем
    }

    const has = new Set(member.roles.cache.filter((r) => MANAGED_ROLE_IDS.has(r.id)).map((r) => r.id));

    for (const roleId of shouldHave) {
      if (!has.has(roleId)) {
        await withTimeout(member.roles.add(roleId), MEMBER_CALL_TIMEOUT_MS, `roles.add(${roleId})`).catch((e) =>
          console.error(`[RoleSync] не удалось выдать роль ${roleId} игроку ${entry.discord_id}:`, e.message)
        );
      }
    }
    for (const roleId of has) {
      if (!shouldHave.has(roleId)) {
        await withTimeout(member.roles.remove(roleId), MEMBER_CALL_TIMEOUT_MS, `roles.remove(${roleId})`).catch((e) =>
          console.error(`[RoleSync] не удалось снять роль ${roleId} у игрока ${entry.discord_id}:`, e.message)
        );
      }
    }
  }
}

// 350+ записей, каждая -- минимум один await (fetch участника + возможные add/remove
// с рейт-лимитом Discord) -- один проход легко может занять дольше SYNC_INTERVAL_MS.
// Без этого флага setInterval запускал бы следующий проход поверх незавершённого:
// два цикла с разными снимками состояния гонялись друг за другом и откатывали
// изменения друг друга (роль то появлялась, то через секунды пропадала).
let syncInProgress = false;

async function runSyncGuarded(client: ExtendedClient): Promise<void> {
  if (syncInProgress) {
    console.warn("[RoleSync] предыдущий проход ещё не завершился — пропускаю этот тик");
    return;
  }
  syncInProgress = true;
  try {
    await syncRoles(client);
  } catch (e) {
    console.error("[RoleSync] ошибка:", e);
  } finally {
    syncInProgress = false;
  }
}

export function startRoleSync(client: ExtendedClient): void {
  runSyncGuarded(client);
  setInterval(() => {
    runSyncGuarded(client);
  }, SYNC_INTERVAL_MS);
}
